import * as puppeteer from 'puppeteer';
import { Page, Frame, WaitForSelectorOptions, JSHandle, KeyInput, Browser } from 'puppeteer';
import * as puppeteer_core from 'puppeteer-core';
import * as puppeteer_with_fingerprints from 'puppeteer-with-fingerprints';

type PuppeteerContext = Page | Frame;
/**
 * A wrapper around Puppeteer's Page or Frame that provides a consistent API for common operations,
 * regardless of whether the underlying context is a Page or a Frame. This allows the rest of the codebase
 * to interact with a single PageContext type without worrying about the specific Puppeteer context type.
 */
declare class PageContext {
    private readonly context;
    private readonly rootPage?;
    constructor(context: PuppeteerContext, rootPage?: Page);
    static fromPage(page: Page): PageContext;
    static fromFrame(frame: Frame, page?: Page): PageContext;
    get raw(): PuppeteerContext;
    get page(): Page | undefined;
    waitForSelector(selector: string, options?: WaitForSelectorOptions): Promise<puppeteer_core.ElementHandle<Element>>;
    $(selector: string): Promise<puppeteer_core.ElementHandle<Element>>;
    $$(selector: string): Promise<puppeteer_core.ElementHandle<Element>[]>;
    $eval<Selector extends string, Params extends unknown[], Func extends (...args: any[]) => any>(selector: Selector, pageFunction: Func, ...args: Params): Promise<any>;
    $$eval<Selector extends string, Params extends unknown[], Func extends (...args: any[]) => any>(selector: Selector, pageFunction: Func, ...args: Params): Promise<any>;
    click(selector: string, options?: any): Promise<void>;
    focus(selector: string): Promise<void>;
    hover(selector: string): Promise<void>;
    tap(selector: string): Promise<void>;
    type(selector: string, text: string, options?: {
        delay?: number;
    }): Promise<void>;
    evaluate<Params extends unknown[], Func extends (...args: any[]) => any>(pageFunction: Func, ...args: Params): Promise<any>;
    evaluateHandle<Params extends unknown[], Func extends (...args: any[]) => any>(pageFunction: Func, ...args: Params): Promise<JSHandle>;
    waitForFunction<Params extends unknown[], Func extends (...args: any[]) => any>(pageFunction: Func, options?: any, ...args: Params): Promise<puppeteer_core.ElementHandle<any> | JSHandle<any>>;
    waitForTimeout(ms: number): Promise<void>;
    content(): Promise<string>;
    title(): Promise<string>;
    url(): string;
    locator(selector: string): puppeteer_core.Locator<Element>;
    select(selector: string, ...values: string[]): Promise<string[]>;
    xpath(xpath: string): Promise<puppeteer_core.ElementHandle<Element>>;
    exists(selector: string): Promise<boolean>;
    visible(selector: string): Promise<boolean>;
    scrollIntoView(selector: string): Promise<void>;
    getValue(selector: string): Promise<string>;
    getText(selector: string): Promise<string>;
    keyboard(): puppeteer_core.Keyboard;
    mouse(): puppeteer_core.Mouse;
    press(key: KeyInput): Promise<void>;
    browser(): Browser | undefined;
}

/**
 * Creates a PageContext for the given page and optional iframe selector.
 * @param page The Puppeteer Page instance to create the context from.
 * @param iframeSelector Optional CSS selector for an iframe within the page. If provided, the context will be created for the iframe's content frame instead of the main page.
 * @returns A Promise that resolves to a PageContext instance representing either the main page or the specified iframe context.
 * @throws Will throw an error if the iframe selector is provided but the iframe cannot be accessed.
 *
 * @example
 *  const ctx = await createContext(page, '#skrining-frame');
    await ctx.waitForSelector('#nik');
    await ctx.type('#nik', nik);
    await ctx.press('Tab');
    const name = await ctx.getValue(
      'input[name="nama_peserta"]'
    );
    const visible = await ctx.visible('#save');
    await ctx.click('#save');
 */
declare function createContext(page: Page, iframeSelector?: string): Promise<PageContext>;

declare class Cookies {
    constructor(id?: string, profileDir?: string);
    id: string;
    profileDir: string;
    getFilePath(): string;
    /**
     * Load cookies into Puppeteer page
     * @param {import('puppeteer').Page} page
     * @param {object} options
     * @returns {Promise<boolean>}
     */
    load(page: puppeteer.Page, options?: object): Promise<boolean>;
    /**
     * Save cookies from Puppeteer page
     * @param {import('puppeteer').Page} page
     * @param {object} options
     * @returns {Promise<string>} file path
     */
    save(page: puppeteer.Page, options?: object): Promise<string>;
    /**
     * Clear cookies file
     * @returns {Promise<boolean>}
     */
    clear(): Promise<boolean>;
    /**
     * Read cookies data from file (no page interaction)
     * @returns {Promise<Array|false>} cookies array or false if not found/invalid
     */
    read(): Promise<any[] | false>;
}

/**
 * Checks if an element matching the selector exists and is visible on the page.
 *
 * @param {import('puppeteer').Page} page - Puppeteer Page instance
 * @param {string} selector - CSS selector for the element to check
 * @returns {Promise<boolean>} Resolves to true if the element exists and is visible, false otherwise
 */
declare function elementExists(page: puppeteer.Page, selector: string): Promise<boolean>;

/**
 * Check if any element matching the selector contains the given text
 *
 * @param {import('puppeteer').Page} page - Puppeteer page instance
 * @param {string} selector - CSS selector (e.g., "form")
 * @param {string} text - Substring to check inside elements
 * @returns {Promise<boolean>}
 */
declare function elementsContainText(page: puppeteer.Page, selector: string, text: string): Promise<boolean>;

/**
 * Check if an element exists with specific text content and is visible
 *
 * @param {import('puppeteer').Page} page Puppeteer Page object
 * @param {string} selector CSS selector to match elements
 * @param {string} text Text content to match
 * @returns {Promise<boolean>} true if element exists and contains the text
 */
declare function elementWithTextExists(page: puppeteer.Page, selector: string, text: string): Promise<boolean>;

/**
 * Options for filtering fingerprints by screen size.
 * @typedef {Object} FingerprintSizeOptions
 * @property {number|string} [width] Exact width to match
 * @property {number|string} [height] Exact height to match
 * @property {number|string} [minWidth] Minimum width (inclusive)
 * @property {number|string} [minHeight] Minimum height (inclusive)
 * @property {number|string} [maxWidth] Maximum width (inclusive)
 * @property {number|string} [maxHeight] Maximum height (inclusive)
 */
/**
 * Get the fingerprint cache directory based on tags.
 *
 * @param {string[]} [tags] - Tags to include in the cache path
 * @returns {string} Fingerprint cache directory path
 */
declare function getFingerprintCacheDir(tags?: string[]): string;
/**
 * Get all cached fingerprints from the cache directory based on tags.
 * Optionally filter cached fingerprints by screen size constraints.
 *
 * @param {string[]} [tags] - Tags to determine cache directory
 * @param {FingerprintSizeOptions} [sizeOptions] - Optional size constraints (see typedef above)
 * @returns {Promise<string[]>} Array of cached fingerprint file paths, sorted by modification time (newest first)
 */
declare function listCachedFingerprintFiles(tags?: string[], sizeOptions?: FingerprintSizeOptions): Promise<string[]>;
/**
 * Get a random cached fingerprint from the cache directory.
 * Optionally filter cached fingerprints by screen size constraints.
 *
 * @param {string[]} [tags] - Tags to determine cache directory
 * @param {FingerprintSizeOptions} [sizeOptions] - Optional size constraints (see typedef above)
 * @returns {Promise<string|null>} Random cached fingerprint content, or null if none found
 */
declare function getRandomCachedFingerprint(tags?: string[], sizeOptions?: FingerprintSizeOptions): Promise<string | null>;
/**
 * Get the most recently cached fingerprint from the cache directory.
 * Optionally filter by screen size constraints.
 *
 * @param {string[]} [tags] - Tags to determine cache directory
 * @param {FingerprintSizeOptions} [sizeOptions] - Optional size constraints (see typedef above)
 * @returns {Promise<string|null>} Most recent cached fingerprint content, or null if cache is empty
 */
declare function getLatestCachedFingerprint(tags?: string[], sizeOptions?: FingerprintSizeOptions): Promise<string | null>;
/**
 * Save fingerprint content into the cache directory.
 *
 * @param {string} fingerprint - Raw fingerprint JSON string.
 * @param {string[]} [tags] - Tags used to determine cache directory.
 * @returns {string} Saved fingerprint file path.
 */
declare function saveFingerprintToCache(fingerprint: string, tags?: string[]): string;
/**
 * Fetch a new fingerprint and save it into the cache directory.
 *
 * @param {string[]|import('puppeteer-with-fingerprints').FetchOptions} [tagsOrOption] - Tags used when fetching and storing fingerprint.
 * @returns {Promise<{ fingerprint: string, filePath: string | null } | null>} Fetched fingerprint and cache path, or null on failure.
 */
declare function fetchAndSaveFingerprintToCache(tagsOrOption?: string[] | puppeteer_with_fingerprints.FetchOptions): Promise<{
    fingerprint: string;
    filePath: string | null;
} | null>;
/**
 * Parse screen size information.
 * Accepts either a data object, a file path to a JSON file, or a JSON string.
 * If a file path is provided, the file will be read and parsed before processing.
 *
 * @param {object|string} data - Data object, JSON string, or filesystem path to JSON file
 * @returns {object|null} Parsed screen size info or null on failure
 */
declare function parseScreenSize(data: object | string): object | null;
/**
 * Options for filtering fingerprints by screen size.
 */
type FingerprintSizeOptions = {
    /**
     * Exact width to match
     */
    width?: number | string;
    /**
     * Exact height to match
     */
    height?: number | string;
    /**
     * Minimum width (inclusive)
     */
    minWidth?: number | string;
    /**
     * Minimum height (inclusive)
     */
    minHeight?: number | string;
    /**
     * Maximum width (inclusive)
     */
    maxWidth?: number | string;
    /**
     * Maximum height (inclusive)
     */
    maxHeight?: number | string;
};

/**
 * Return the currently active/focused Page in a Browser, if detectable.
 *
 * This attempts to evaluate `document.hasFocus()` in each open page and
 * returns the first page that reports focus. If none report focus, it
 * falls back to the last opened page or null if no pages exist.
 *
 * @param {import('puppeteer').Browser} browser
 * @returns {Promise<import('puppeteer').Page|null>}
 */
declare function getActivePage(browser: puppeteer.Browser): Promise<puppeteer.Page | null>;

/**
 * Returns the first available fallback profile directory path.
 *
 * @param {number} [startIndex=1] - First profile index to probe.
 * @param {string[]} [excludedDirs=[]] - Directories to skip when selecting fallback profile.
 * @returns {string}
 */
declare function getFallbackProfileDir(startIndex?: number, excludedDirs?: string[]): string;

/**
 * Extracts attribute values and common properties from input and textarea elements.
 *
 * NOTE: This function is executed inside the browser context (for example via `$$eval`).
 * It returns plain JSON-serializable objects and must not rely on external variables or
 * runtime helpers.
 *
 * @param {HTMLInputElement[]|HTMLTextAreaElement[]} elements - Array of input or textarea elements from the DOM.
 * @returns {Array<Object>} Array of plain objects with attributes and common properties.
 */
declare function extractFormValues(elements: HTMLInputElement[] | HTMLTextAreaElement[]): Array<any>;
/**
 * Get values of all input and textarea elements within a container inside an iframe.
 *
 * @param {import('puppeteer').Page} page - The Puppeteer page instance.
 * @param {string} iframeSelector - The CSS selector for the iframe.
 * @param {string} containerSelector - The CSS selector for the container inside the iframe.
 * @returns {Promise<Array<Object>>}
 */
declare function getFormValuesFromFrame(page: puppeteer.Page, iframeSelector: string, containerSelector: string): Promise<Array<any>>;

/**
 * Navigate a Puppeteer `page` to `url` with retries and exponential backoff.
 * @param {import('puppeteer').Page} page
 * @param {string} url
 * @param {object} [opts]
 * @param {number} [opts.retries=3] - Number of retry attempts (not counting the first try).
 * @param {number} [opts.timeout=30000] - Navigation timeout in ms.
 * @param {string|string[]} [opts.waitUntil='networkidle2'] - Puppeteer waitUntil option.
 * @param {import('./Cookies.js').PuppeteerCookies} [opts.cookie] - Optional PuppeteerCookies instance to load cookies before navigation.
 * @param {number} [opts.retryDelay=1000] - Initial delay in ms between retries (exponential backoff).
 * @param {function} [opts.onRetry] - Optional callback called before each retry with {attempt, err, delay}.
 * @returns {Promise<import('puppeteer').HTTPResponse|null>}
 */
declare function goWithRetry(page: puppeteer.Page, url: string, opts?: {
    retries?: number;
    timeout?: number;
    waitUntil?: string | string[];
    cookie?: Cookies;
    retryDelay?: number;
    onRetry?: Function;
}): Promise<puppeteer.HTTPResponse | null>;

declare class EndpointManager {
    basePath: string;
    endpointFile: string;
    endpointLocksPath: string;
    constructor(basePath: string);
    private parseEndpoints;
    private getEndpointLockPath;
    private readEndpointLock;
    private isProcessRunning;
    private getActiveEndpointLock;
    isEndpointLocked(endpoint: string): boolean;
    readEndpoints(): string[];
    writeEndpoint(endpoint: string): void;
    removeEndpoint(endpoint: string): void;
    /**
     * Checks if a Puppeteer endpoint is available by attempting Puppeteer.connect.
     */
    private isPuppeteerEndpointAvailable;
    /**
     * Returns the first available endpoint (not locked, not stale, and Puppeteer responds)
     */
    getAvailableEndpoint(): Promise<string | undefined>;
    /**
     * Returns all endpoints with their lock status, inactive status, and Puppeteer availability
     */
    getAllActiveEndpoints(): Promise<any[]>;
    tryClaimEndpoint(endpoint: string, ownerPid: number): boolean;
    releaseEndpointClaim(endpoint: string, ownerPid: number): void;
    readEndpointStatus(): {
        endpoint: string;
        inUse: boolean;
        ownerPid: number;
    }[];
}

/**
 * Acquire a Puppeteer `page` and `browser` connected to an available shared browser endpoint.
 *
 * This function will try to claim an available endpoint via the local `EndpointManager`,
 * connect using `getPuppeteer`, and return the connected `page` and `browser` together with
 * the managing `endpointManager`, the claimed `endpoint` string, and a `release` helper to
 * free the claim (and optionally close the browser) when finished.
 *
 * @async
 * @param options Optional options forwarded to `getPuppeteer` (e.g. for puppeteer.connect).
 * @returns An object: `{ page, browser, endpoint, endpointManager, release }`.
 */
declare function getPuppeteerWithParallel(options?: {}): Promise<{
    page: puppeteer_core.Page;
    browser: puppeteer_core.Browser;
    endpoint: string;
    endpointManager: EndpointManager;
    release: (closeBrowser?: boolean) => Promise<void>;
}>;

/**
 * Launches a Puppeteer browser instance in the background for parallel usage.
 *
 * Opens a maximized browser with stealth mode enabled, navigates to the
 * initial URL, and sets up target lifecycle listeners (`targetcreated`,
 * `targetdestroyed`, `targetchanged`) that refresh the shared WebSocket
 * endpoint file whenever targets change.
 *
 * After the browser is ready the function:
 * - Writes the browser's WebSocket endpoint so other processes can connect
 * - Removes stale/unavailable endpoints from the registry
 * - Creates a PID-based running-indicator file under `puppeteerTempPath`
 *
 * The returned promise never resolves — it keeps the process alive until the
 * browser disconnects or the process receives `SIGINT`, `SIGTERM`, or `exit`,
 * at which point the endpoint is cleaned up.
 */
declare function parallelLauncher(): Promise<void>;

declare const endpointManager: EndpointManager;
/**
 * Spawns a detached child process that runs the Puppeteer launcher
 * (`launcher.runner.ts` or its compiled `.js` counterpart).
 *
 * Waits up to 60 seconds for a running-indicator file to appear under
 * `puppeteerTempPath`. Throws if the child exits prematurely or the
 * timeout is exceeded.
 *
 * @returns A promise that resolves once the browser process signals it is ready
 */
declare function launch(): Promise<void>;
/**
 * Connects to an available Puppeteer browser endpoint.
 *
 * Queries the {@link endpointManager} for active endpoints. If none exist, or
 * no free endpoint can be claimed, a new browser is launched automatically via
 * {@link launch}.
 *
 * The function loops until it can claim an unlocked, Puppeteer-responsive
 * endpoint. Dead endpoints (`ECONNREFUSED`) are removed from the registry
 * transparently. Once a connection is established a `disconnected` listener
 * releases the claim.
 *
 * @returns A promise that resolves with a connected {@link Browser} instance
 * @throws If no endpoint can be obtained after repeated launch attempts
 */
declare function connect(): Promise<Browser>;

/**
 * Processes screening data, reusing existing screenshots when possible and fetching new ones when needed.
 */
declare function parallelSkrinCheck(options?: {
    specificNiks?: string[];
    force?: boolean;
    openScreenshots?: boolean;
    limit?: number;
    fromDate?: string;
    toDate?: string;
}): Promise<void>;
declare const parallelSkrinCheckEndpointManager: EndpointManager;
declare function getParallelSkrinCheckClaimedEndpoint(): string;

declare function parallelSkrin(opts: {
    loop?: boolean;
    max?: number;
    argv: Record<string, any>;
}): Promise<void>;

/**
 * Triggers 'input' and 'change' events on an input or textarea element,
 * optionally within an iframe. Does NOT change the element’s value.
 *
 * @param {import('puppeteer').Page} page - Puppeteer Page object
 * @param {string} selector - CSS selector for the input or textarea
 * @param {Object} [options]
 * @param {string} [options.frameSelector] - Optional iframe CSS selector
 * @param {string} [options.frameName] - Optional iframe name
 */
declare function triggerInputChange(page: puppeteer.Page, selector: string, options?: {
    frameSelector?: string;
    frameName?: string;
}): Promise<void>;

declare function setupXhrCapture(page: Page, opts?: {
    baseDir?: string;
}): () => Promise<void>;

type lib_EndpointManager = EndpointManager;
declare const lib_EndpointManager: typeof EndpointManager;
type lib_FingerprintSizeOptions = FingerprintSizeOptions;
type lib_PageContext = PageContext;
declare const lib_PageContext: typeof PageContext;
type lib_PuppeteerContext = PuppeteerContext;
declare const lib_connect: typeof connect;
declare const lib_createContext: typeof createContext;
declare const lib_elementExists: typeof elementExists;
declare const lib_elementWithTextExists: typeof elementWithTextExists;
declare const lib_elementsContainText: typeof elementsContainText;
declare const lib_endpointManager: typeof endpointManager;
declare const lib_extractFormValues: typeof extractFormValues;
declare const lib_fetchAndSaveFingerprintToCache: typeof fetchAndSaveFingerprintToCache;
declare const lib_getActivePage: typeof getActivePage;
declare const lib_getFallbackProfileDir: typeof getFallbackProfileDir;
declare const lib_getFingerprintCacheDir: typeof getFingerprintCacheDir;
declare const lib_getFormValuesFromFrame: typeof getFormValuesFromFrame;
declare const lib_getLatestCachedFingerprint: typeof getLatestCachedFingerprint;
declare const lib_getParallelSkrinCheckClaimedEndpoint: typeof getParallelSkrinCheckClaimedEndpoint;
declare const lib_getPuppeteerWithParallel: typeof getPuppeteerWithParallel;
declare const lib_getRandomCachedFingerprint: typeof getRandomCachedFingerprint;
declare const lib_goWithRetry: typeof goWithRetry;
declare const lib_launch: typeof launch;
declare const lib_listCachedFingerprintFiles: typeof listCachedFingerprintFiles;
declare const lib_parallelLauncher: typeof parallelLauncher;
declare const lib_parallelSkrin: typeof parallelSkrin;
declare const lib_parallelSkrinCheck: typeof parallelSkrinCheck;
declare const lib_parallelSkrinCheckEndpointManager: typeof parallelSkrinCheckEndpointManager;
declare const lib_parseScreenSize: typeof parseScreenSize;
declare const lib_saveFingerprintToCache: typeof saveFingerprintToCache;
declare const lib_setupXhrCapture: typeof setupXhrCapture;
declare const lib_triggerInputChange: typeof triggerInputChange;
declare namespace lib {
  export { lib_EndpointManager as EndpointManager, lib_PageContext as PageContext, Cookies as PuppeteerCookies, lib_connect as connect, lib_createContext as createContext, lib_elementExists as elementExists, lib_elementWithTextExists as elementWithTextExists, lib_elementsContainText as elementsContainText, lib_endpointManager as endpointManager, lib_extractFormValues as extractFormValues, lib_fetchAndSaveFingerprintToCache as fetchAndSaveFingerprintToCache, lib_getActivePage as getActivePage, lib_getFallbackProfileDir as getFallbackProfileDir, lib_getFingerprintCacheDir as getFingerprintCacheDir, lib_getFormValuesFromFrame as getFormValuesFromFrame, lib_getLatestCachedFingerprint as getLatestCachedFingerprint, lib_getParallelSkrinCheckClaimedEndpoint as getParallelSkrinCheckClaimedEndpoint, lib_getPuppeteerWithParallel as getPuppeteerWithParallel, lib_getRandomCachedFingerprint as getRandomCachedFingerprint, lib_goWithRetry as goWithRetry, lib_launch as launch, lib_listCachedFingerprintFiles as listCachedFingerprintFiles, lib_parallelLauncher as parallelLauncher, lib_parallelSkrin as parallelSkrin, lib_parallelSkrinCheck as parallelSkrinCheck, lib_parallelSkrinCheckEndpointManager as parallelSkrinCheckEndpointManager, lib_parseScreenSize as parseScreenSize, lib_saveFingerprintToCache as saveFingerprintToCache, lib_setupXhrCapture as setupXhrCapture, lib_triggerInputChange as triggerInputChange };
  export type { lib_FingerprintSizeOptions as FingerprintSizeOptions, lib_PuppeteerContext as PuppeteerContext };
}

export { EndpointManager, PageContext, Cookies as PuppeteerCookies, connect, createContext, lib as default, elementExists, elementWithTextExists, elementsContainText, endpointManager, extractFormValues, fetchAndSaveFingerprintToCache, getActivePage, getFallbackProfileDir, getFingerprintCacheDir, getFormValuesFromFrame, getLatestCachedFingerprint, getParallelSkrinCheckClaimedEndpoint, getPuppeteerWithParallel, getRandomCachedFingerprint, goWithRetry, launch, listCachedFingerprintFiles, parallelLauncher, parallelSkrin, parallelSkrinCheck, parallelSkrinCheckEndpointManager, parseScreenSize, saveFingerprintToCache, setupXhrCapture, triggerInputChange };
export type { FingerprintSizeOptions, PuppeteerContext };
