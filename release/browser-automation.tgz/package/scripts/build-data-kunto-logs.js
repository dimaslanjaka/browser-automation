import { loadCsvData } from '../data/index.js';
import { getLogs } from '../src/database/SQLiteLogDatabase.js';
import { fixData } from '../src/xlsx-helper.js';

async function buildDataKuntoLogs() {
  const dataKunto = await loadCsvData();
  let liveLogs = getLogs();
  // Sort liveLogs by item.data.nik order as in dataKunto
  if (Array.isArray(dataKunto) && Array.isArray(liveLogs)) {
    const nikOrder = dataKunto.map((item) => item.nik);
    const nikIndex = (nik) => nikOrder.indexOf(nik);
    liveLogs = liveLogs.slice().sort((a, b) => {
      const nikA = a.data && a.data.nik;
      const nikB = b.data && b.data.nik;
      return nikIndex(nikA) - nikIndex(nikB);
    });
  }
  const find = (data) => liveLogs.filter((item) => item.data.nik === data || item.data.nama === data);
  const findLog = find('MOCH.SAMSUDIN')[0];
  console.log('Original Log Data for MOCH.SAMSUDIN:', findLog);
  const fixedData = await fixData(findLog ? findLog.data : {}, { autofillTanggalEntry: true }).catch((e) => {
    console.log('Error fixing data:', e);
    return null;
  });
  console.log('Fixed Data for MOCH.SAMSUDIN:', fixedData);
}

buildDataKuntoLogs();
